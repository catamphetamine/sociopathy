function initialize_page()
{
}