﻿// button skin specific settings
text_button.add_skin('sociopathy',
{ 
	path: 'картинки/button',
	'image format': 'png',
	height: 59,
	'side bar size': 44,
})
